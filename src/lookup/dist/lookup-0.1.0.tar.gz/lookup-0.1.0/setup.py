# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lookup']

package_data = \
{'': ['*']}

install_requires = \
['docarray==0.17.0', 'pytest==6.2.4']

setup_kwargs = {
    'name': 'lookup',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Fernando Gonzalez',
    'author_email': 'fernandogonzalez512@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
