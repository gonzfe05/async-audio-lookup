# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lookup']

package_data = \
{'': ['*']}

install_requires = \
['datasets[audio]>=2.5.2,<3.0.0',
 'docarray[redis]==0.19.0',
 'jiwer>=2.5.1,<3.0.0',
 'librosa==0.9.2',
 'protobuf==4.21.9',
 'pydub>=0.25.1,<0.26.0',
 'pytest==6.2.4',
 'torch==1.12.1']

setup_kwargs = {
    'name': 'lookup',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Fernando Gonzalez',
    'author_email': 'fernandogonzalez512@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
