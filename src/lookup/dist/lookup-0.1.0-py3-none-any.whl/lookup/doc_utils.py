import os
from typing import Generator, List, Optional
from docarray import DocumentArray, Document

STORAGE = os.getenv('DOCARRAY_STORAGE_BACKEND')
assert STORAGE
STORE_CONF = {'host': os.getenv('DOCARRAY_STORAGE_HOST'),
              'port': os.getenv('DOCARRAY_STORAGE_PORT'),
              'index_name': os.getenv('DOCARRAY_STORAGE_INDEX')}


def _extend_docstore(storage: str, config: dict, docs_kwargs: List[dict]):
    with DocumentArray(storage, config) as da:
        da.extend([Document(**kwargs) for kwargs in docs_kwargs])
        return len(da)

def _add_doc(uris: List[str], labels: List[str], n_dim: int, storage: str = STORAGE, config: dict = STORE_CONF):
    assert len(uris) == len(labels)
    config['n_dim'] = n_dim
    metadata = [{'label': l} for l in labels]
    docs_kwargs = [{'uri': u, 'tags': m} for u, m in zip(uris, metadata)]
    return _extend_docstore(storage, config, docs_kwargs)

def _get_doc_by_uri(uri: str, n_dim: int, storage: str = STORAGE, config: dict = STORE_CONF):
    config['n_dim'] = n_dim
    with DocumentArray(storage, config) as da:
        return da.find({'uri': {'$eq': uri}})

def _get_array_by_uris(uris: List[str], n_dim: int, storage: str = STORAGE, config: dict = STORE_CONF):
    config['n_dim'] = n_dim
    with DocumentArray(storage, config) as da:
        return da.find({'uri': {'$in': uris}})

def _doc_audio_to_tensor(doc: Document) -> Document:
    return doc.load_uri_to_audio_tensor()

def _array_audio_to_tensor(da: DocumentArray) -> DocumentArray:
    return da.apply(_doc_audio_to_tensor)

def _iter_audio_batch(da: DocumentArray, batch: int = 16) -> Generator[DocumentArray, None, None]:
    return da.apply_batch(_array_audio_to_tensor, batch_size=batch)